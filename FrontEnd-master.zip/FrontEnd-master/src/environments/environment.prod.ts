export const environment = {
  production: true,


//URL of development API

apiURL: 'http://localhost:3000'

};

